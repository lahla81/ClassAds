<ul class="nav justify-content-center">
    <?php echo $__env->make('lists.categoryNav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</ul>