@extends('layouts.app')

@section('title', "رئيسية الموقع")

@section('content')
    <h1>الصفحة الرئيسية</h1>
@endsection