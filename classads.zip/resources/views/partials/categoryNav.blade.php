<ul class="nav justify-content-center">
    @include('lists.categoryNav')
</ul>